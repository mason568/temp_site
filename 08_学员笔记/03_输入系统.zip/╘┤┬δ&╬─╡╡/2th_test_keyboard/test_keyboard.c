#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <linux/input.h>

int main(void)
{
    //1、定义一个结构体变量用来描述input事件
    struct input_event event_keyboard ;
    //2、打开input设备的事件节点  我的通用键盘事件的节点是event1
    int fd    = -1 ;
	fd = open("/dev/input/event1", O_RDONLY);
    if(-1 == fd)
    {
        printf("open mouse event fair!\n");
        return -1 ;
    }
    while(1)
    {
        //3、读事件
        read(fd, &event_keyboard, sizeof(event_keyboard));
		if(EV_KEY == event_keyboard.type)
		{
				if(1 == event_keyboard.value)
					printf("事件类型:%d  事件值:%d 按下\n",event_keyboard.type,event_keyboard.code);
				else if(0 == event_keyboard.value)
					printf("事件类型:%d  事件值:%d 释放\n",event_keyboard.type,event_keyboard.code);
		}
    }
    close(fd);
    return 0 ;
}
