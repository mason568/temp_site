#ifndef __ADC_H
#define __ADC_H

#include "common.h"

int adc_init(void);
unsigned int  adc_value(void);
unsigned short adc_avr(unsigned char times);
		  			 		  						  					  				 	   		  	  	 	  

#endif