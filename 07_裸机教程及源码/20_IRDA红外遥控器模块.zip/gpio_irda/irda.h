#ifndef _IRDA_H
#define _IRDA_H

#include "timer.h"
#include "uart.h"
#include "my_printf.h"
		  			 		  						  					  				 	   		  	  	 	  
void value_show(void);

#endif
