#include <stdio.h>
#include "test.h"

#define HUNDRED 100

int main()
{
	printf("%d ask\n",HUNDRED);
	return 0;
}
		  			 		  						  					  				 	   		  	  	 	  