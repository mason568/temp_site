#include <stdio.h>

#define HUNDRED 100

int main()
{
	int a = 0;
	printf("%d ask\n",HUNDRED);
	return 0;
}
		  			 		  						  					  				 	   		  	  	 	  