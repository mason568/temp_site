#include <stdio.h>
#include "add.h"

int main(int argc, char *argv[])
{
	printf("%d\n",add(10, 10));
	printf("%d\n",add(20, 20));
	return 0;
}
