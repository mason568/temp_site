#ifndef __ADD_H
#define __ADD_H

int add(int a, int b);

#endif 
		  			 		  						  					  				 	   		  	  	 	  