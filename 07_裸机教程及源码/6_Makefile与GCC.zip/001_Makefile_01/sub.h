#ifndef __SUB_H
#define __SUB_H

int sub(int a, int b);

#endif 
		  			 		  						  					  				 	   		  	  	 	  