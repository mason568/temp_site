#ifndef _SR04_H
#define _SR04_H

#include "timer.h"
#include "gic.h"
#include "uart.h"
#include "my_printf.h"
		  			 		  						  					  				 	   		  	  	 	  

void start_sr04(void);

#endif
