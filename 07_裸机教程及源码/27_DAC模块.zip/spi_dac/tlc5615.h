#ifndef _TLC5615_H_
#define _TLC5615_H_
		  			 		  						  					  				 	   		  	  	 	  
void delay_x(unsigned short uc_x);

void tlc5615_write_addr(unsigned short uc_data);
unsigned char tlc5615_init(void);
		  			 		  						  					  				 	   		  	  	 	  

#endif

